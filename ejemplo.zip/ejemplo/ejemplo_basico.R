library(shiny)
library(shinydashboard)
library(DT)


ui <- dashboardPage(
  dashboardHeader( title = "Ejemplo Basico"),
  
  dashboardSidebar(
    sidebarMenu(id="sbmenu",
                menuItem("Subir Archivo",tabName = "menu1"),
                
                menuItem("Estadisticas \nDescriptivas",tabName = "menu2",
                         menuSubItem('Estadisticas \nDescriptivas', tabName = 'menu21'),
                         menuSubItem('Graficos', tabName = 'menu22'),
                         menuSubItem('Diagrama de dispersi�n', tabName = 'menu23')),
                menuItem("Regresi�n simple",tabName = "menu3")
                         #menuSubItem('Sub Menu 3', tabName = 'menu23')
                
    )
  ),
  
  dashboardBody(
    tabItems(
      tabItem("menu1",
              fluidPage(
                
                  titlePanel("Archivo de datos"),
                  
                  sidebarLayout(
                    sidebarPanel(
                      fileInput("archivo",label = "Archivo", accept = c( "text/csv",
                                      "text/comma-separated-values,text/plain",".csv")),
                      checkboxInput("header", "Encabezado", TRUE),
                      radioButtons("sep", "Separador", choices = c(Coma = ",","Punto y Coma" = ";",Tab= "\t"),
                           selected = ";", inline = T),
                      tags$hr(),
                      radioButtons("disp", "Mostrar", choices = c("Los primeros datos" = "head", "Todos" = "all"),
                           selected = "head"),
                      width = 7, scrollX = TRUE
                      
                      ),
                    mainPanel( DT::dataTableOutput("datos")), fluid = TRUE
                    )
                )
              
      ),
      tabItem("menu21",
              fluidPage(
                
                titlePanel("Estadisticas descriptivas"),
                
                sidebarLayout(
                  sidebarPanel(
                    numericInput("obs", "Numero de la columna a analizar", NULL, min = 1, max = 100),
                    tags$hr(),
                    
                    radioButtons("botones", "Tipo de Variable",
                                 c("Cualitativa","Cuantitativa"), selected = NULL)
                  ),
                    
                  mainPanel(tableOutput("descrip")), fluid = TRUE
                )
              )
              ),
      tabItem("menu22",
              fluidPage(
                
          
                sidebarLayout(
                  sidebarPanel(
                    titlePanel("Graficos descriptivos"),
                    numericInput("obs1", "Columna a Analizar", NULL, min = 1, max = 100),
                    tags$hr(),
                    radioButtons("grafico",label = "Graficos",
                                 c("Barras"="bar",
                                   "Torta"="pie",
                                   "Histograma"="hist",
                                   "Diagrama de Cajas"="boxplot"), selected = NULL
                                 ),
                    width = 7
                  ),
                  
                  
                  mainPanel(plotOutput("graf"))
                )
                )
              ),
                
                tabItem("menu23",
                        fluidPage(
                sidebarLayout(
                sidebarPanel(
                  titlePanel("Diagrama de dispersion"),
                  
                  numericInput("x", "Numero de la columna para la variable X", NULL, min = 1, max = 100),
                  numericInput("y", "Numero de la columna para la variable y", NULL, min = 1, max = 100),
                  width = 7
                ),
                mainPanel(plotOutput("dispersion"))
                )
                        )
      ),
      tabItem("menu3",
              fluidPage(
                sidebarLayout(
                  sidebarPanel(
                    titlePanel("Regresi�n Simple"),
                    
                    numericInput("x1", "Variable X", NULL, min = 1, max = 100),
                    numericInput("y1", "variable y", NULL, min = 1, max = 100),
                    radioButtons("supuesto","Supuestos del modelo",
                                 c("Si","No"),inline = TRUE,selected = "No"),
                    radioButtons("anova","Analisis de Varianza",
                                 c("Si","No"),inline = TRUE,selected = "No"),
                    width = 7
                  ),
                  mainPanel(tableOutput("coefic"), plotOutput("supues"), verbatimTextOutput("anov",placeholder = T))
                )
              )
      )
      )
  )
)



server <- function(input, output) {
  observe(print(input$sbmenu))
  
  output$datos <- DT::renderDataTable({
    inFile <- input$archivo
    if (is.null(inFile)){return(NULL)}
    else if (is.null(inFile)==FALSE){
      
      base<-read.csv(inFile$datapath,
                     header = input$header,
                     sep = input$sep)
      
      tabla<-DT::datatable(base, filter="top",options = list(autoWidth = F, scrollX = TRUE))$x$data
      if(input$disp == "head") { 
        return(head(tabla)) }
      else {
        return(tabla)}
      }
  })
  
  
  output$descrip <- renderTable({
    req(input$archivo)
    req(input$obs)
    
    inFile <- input$archivo
    if (is.null(inFile)==FALSE){
      base<-read.csv(inFile$datapath, header = TRUE, sep=";")}
    
    col<-input$obs
    
    if(input$botones=="Cualitativa"){
      
     x<-as.factor(base[,col])
     b<-table(x)
     des<-matrix(0,length(b),2)
     colnames(des)<-c("Frecuencia","Porcentaje")
     des[,1]<-t(b)
     des[,2]<-(t(b)/length(x))*100
     Categoria<-levels(x)
     descrip<-data.frame(Categoria,des)
     
     return(descrip)
      
    }
    else if(input$botones=="Cuantitativa"){
      nom<-c("Media","Varianza","Desviacion Estandar", "CV","Cuartil 1","Mediana","Cuartil 3")
      des<-numeric()
      des[1]<-mean(base[,col])
      des[2]<-var(base[,col])
      des[3]<-sd(base[,col])
      des[4]<-sd(base[,col])/mean(base[,col])
      des[5]<-quantile(base[,col],0.25)
      des[6]<-median(base[,col])
      des[7]<-quantile(base[,col],0.75)
      
      descriptiva<-data.frame(nom,des)
      colnames(descriptiva)<-c("Estadistico","Valor")
      
      return(descriptiva)}
    
  })
  
  
  output$graf <- renderPlot({
    req(input$archivo)
    req(input$obs1)
    
    inFile <- input$archivo
    if (is.null(inFile)==FALSE){
      base<-read.csv(inFile$datapath, header = TRUE, sep=";")}
    
    col<-input$obs1
    nom<-names(base)
    
    if(input$grafico=="bar"){
      v<-table(base[,col])
      barplot(v,col=rainbow(7), main = paste("Diagrama de barra para",nom[col]))}
    
    else if (input$grafico=="pie"){
      v<-table(base[,col])
      pie(v,col=rainbow(7),main = paste("Diagrama de torta para",nom[col]))}
    
    else if (input$grafico=="hist"){
      hist(base[,col],col=rainbow(7),main = paste("Histograma para",nom[col]))}
    
    else if (input$grafico=="boxplot"){
      boxplot(base[,col],col="blue",main = paste("Diagrama de cajas y bigotes para",nom[col]))}
    
})
  
  output$dispersion <- renderPlot({
    req(input$archivo)
    req(input$x)
    req(input$y)
    inFile <- input$archivo
    if (is.null(inFile)==FALSE){
      base<-read.csv(inFile$datapath, header = TRUE, sep=";")}
    
    x<-input$x
    y<-input$y
    nom<-names(base)
    plot(base[,x],base[,y],xlab=nom[x], ylab=nom[y], main="Diagrama de dispersi�n",
         sub = paste("coeficiente de correlaci�n=",cor(base[,x],base[,y])))
    
    
  })
  
  

  output$coefic<-renderTable({
    
    req(input$archivo)
    req(input$x1)
    req(input$y1)
    
    inFile <- input$archivo
    if (is.null(inFile)==FALSE){
      base<-read.csv(inFile$datapath, header = TRUE, sep=";")}
    
    x<-input$x1
    y<-input$y1
    modelo<-lm(base[,y]~base[,x], data=base)
    coef<-matrix(0,2,3)
    colnames(coef)<-c("Estimador","Lim Inf","Lim Sup")
    Parametro<-c("Intercepto","Variable")
    coef[,1]<-t(modelo$coefficients)
    coef[,2:3]<-confint(modelo, level = 0.95)
    
    coefi<-data.frame(Parametro,coef)
    
    return(coefi)
  })
  
  output$supues<-renderPlot({
    
    req(input$archivo)
    req(input$x1)
    req(input$y1)
    
    inFile <- input$archivo
    if (is.null(inFile)==FALSE){
      base<-read.csv(inFile$datapath, header = TRUE, sep=";")}
    
    x<-input$x1
    y<-input$y1
    modelo<-lm(base[,y]~base[,x], data=base)
    if(input$supuesto=="Si"){
    par(mfrow=c(2,2))
    plot(modelo)}
    
    else{
      return(NULL)
    }
    
   
  })
  
  
  output$anov<-renderPrint({
    
    req(input$archivo)
    req(input$x1)
    req(input$y1)
    
    inFile <- input$archivo
    if (is.null(inFile)==FALSE){
      base<-read.csv(inFile$datapath, header = TRUE, sep=";")}
    
    x<-input$x1
    y<-input$y1
    if(input$anova=="Si"){
      modelo<-lm(base[,y]~base[,x], data=base)
    
   anova(modelo)}
    
    else{
      return(NULL)
    }
    
    
    
  })
  
  
  

}

shinyApp(ui,server)

